import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;



public class Main
{
	private static Ponto mapa[][]= new Ponto[5][5];
	private static ArrayList<Ponto> aberta = new ArrayList();
	private static ArrayList<Ponto> fechada = new ArrayList();
	
	static final int tamanho_da_matriz=5;
	 		
	 
			
	public static void main(String[] args)
	{
		Scanner leia = new Scanner(System.in);
		
		for(int cont=0;cont<tamanho_da_matriz;cont++)
		{
			for(int cont2=0;cont2<tamanho_da_matriz;cont2++)
			{
				mapa[cont][cont2] = new Ponto();
				mapa[cont][cont2].setX(cont);
				mapa[cont][cont2].setY(cont2);
			}
		}
		 
		// area de testes abaixo    
		  
		mapa[1][2].setBloquado(true);
		//mapa[2][2].setBloquado(true);
		mapa[3][2].setBloquado(true);
		
		
		mapa[2][0].setOrigem(true);
		mapa[2][4].setDestino(true);
		
		// fim da area de testes
		
		mostrar_mapa(mapa);
		System.out.println();
		System.out.println();
		Ponto atual = mapa[2][0];	// define o ponto de analise inicial como sendo o da origem
		Ponto destino = mapa[2][4];
		aberta.add(atual);
		boolean  caminho_encontrado = false;
		
		do {
			Collections.sort(aberta);	//ordenando a lista
			
			//if(!aberta.isEmpty())
			//{
				atual = aberta.get(0);		// atual recebe o ponto de aberta com menor custo
				//System.out.println("Aberta tamanho: "+aberta.size());
				//System.out.println("Fechada tamanho: "+fechada.size());
				//System.out.println("Atual: ["+atual.getX()+", "+atual.getY()+"] ");
				aberta.remove(atual);		// tirando o elemento atual da lista aberta
				fechada.add(atual);			// e colocando na lista fechada
			
				// esquerda cima para direita baixo
				
				manipula_vizinho(atual.getX()-1,atual.getY()-1,atual.getX(),atual.getY(),destino.getX(),destino.getY());	// 0,0
				manipula_vizinho(atual.getX()-1,atual.getY(),atual.getX(),atual.getY(),destino.getX(),destino.getY());		// 0,1
				manipula_vizinho(atual.getX()-1,atual.getY()+1,atual.getX(),atual.getY(),destino.getX(),destino.getY());	// 0,2
				manipula_vizinho(atual.getX(),atual.getY()-1,atual.getX(),atual.getY(),destino.getX(),destino.getY());		// 1,0
				manipula_vizinho(atual.getX(),atual.getY()+1,atual.getX(),atual.getY(),destino.getX(),destino.getY());		// 1,2
				manipula_vizinho(atual.getX()+1,atual.getY()-1,atual.getX(),atual.getY(),destino.getX(),destino.getY());	// 2,0
				manipula_vizinho(atual.getX()+1,atual.getY(),atual.getX(),atual.getY(),destino.getX(),destino.getY());		// 2,1
				manipula_vizinho(atual.getX()+1,atual.getY()+1,atual.getX(),atual.getY(),destino.getX(),destino.getY());	// 2,2
				if(atual.isDestino())
				{
					caminho_encontrado =true;
				}
			
			//}
		}while(!aberta.isEmpty() && !atual.isDestino());
		
		
		// se encontrou o caminho sair percorrendo do destino at� o inicio e marcando os n�s como caminho
		if(caminho_encontrado)
		{
			System.out.println("encontrou o caminho");
			/*
			  	
			 
			// otimizando o caminho
			boolean cond = true;
			Ponto pai =destino.getPai(),avo=destino.getPai().getPai(),filho = destino;
			while (pai != null && avo != null)
			{
				if(eh_vizinho(pai.getX(),filho.getX(),pai.getY(),filho.getY()) && eh_vizinho(avo.getX(), filho.getX(), avo.getY(), filho.getY()))
				{
					filho.setPai(avo);
					pai = filho.getPai();
					avo= pai.getPai();
				}
			}
			System.out.println("saiu do while");
			// fim da otimizacao
			 * 
			 */
			boolean cond_parada = false;
			Ponto temp = destino.getPai();
			while(!cond_parada)
			{
				
				temp.setCaminho(true);
				if(temp.getPai() != null)
				{
					temp = temp.getPai();
				}else
				{
					cond_parada = true;
				}
			}
			
		}
		else {
			System.out.println("n�o encontrou o caminho");
		}
		
		
		
		
		mostrar_mapa(mapa);
				
	}
	
	
	
	
	
	
	
	public static void mostrar_mapa(Ponto mapa[][])
	{
		for(int cont=0;cont<tamanho_da_matriz;cont++)
		{
			for(int cont2=0;cont2<tamanho_da_matriz;cont2++)
			{
				if(mapa[cont][cont2].isBloquado())
				{
					System.out.print('1');		//bloqueado
				}	
				else {
					if(mapa[cont][cont2].isOrigem())
					{
						System.out.print('Z');	//ponto inicial do jogo
					}else
					{
						if(mapa[cont][cont2].isDestino())
						{
							System.out.print('C'); //ponto final do jogo
						}else
						{
							if(mapa[cont][cont2].isCaminho())
							{
								System.out.print('X');	//caminho tracejado como melhor possivel
							}else
							{
								System.out.print('0');	// livre
							}
							
						}
					}
				}
				if(cont2 != tamanho_da_matriz-1)
				{
					System.out.print(' ');		// s� coloca o espa�o se n�o for o ultimo elemento de uma linha
				}
			}
			System.out.println();
		}
	}
	
	public static void manipula_vizinho(int posx,int posy, int posx_atual,int posy_atual,int posx_final,int posy_final)
	{			// vizinho a ser analizado= {posx,posy}, posicao atual = {posx_atual,posy_atual}, destino = {posx_final,posy_final}
		if((posx >=0 && posx <tamanho_da_matriz) && (posy>=0 && posy<tamanho_da_matriz))
		{
			
			if(eh_permitido(posx,posx_atual,posy,posy_atual))	// se o movimento for v�lido, isto eh, n�o for um passo diagonal passando pela quina da parede
			{
				if(!mapa[posx][posy].isBloquado()  && !fechada.contains(mapa[posx][posy]) )		// vizinho nao esta bloqueado nem na lista fechada
				{
					if(!aberta.contains(mapa[posx][posy]))										// vizinho nao esta na lista aberta
					{
						
						mapa[posx][posy].setPai(mapa[posx_atual][posy_atual]);					// definindo o pai do vizinho como sendo o no atual
						if(mapa[posx][posy].calcula_distancia_entre_pontos(mapa[posx][posy], mapa[posx_atual][posy_atual])!= 1) // movimento diagonal
						{
							mapa[posx][posy].setG(14);
						}else
						{
							mapa[posx][posy].setG(10);                 							// movimento horizontal ou vertical
						}
						
						// distancia entre o no vizinho e o destino final (heuristica manhattan)
						mapa[posx][posy].setH(mapa[posx][posy].calcula_distancia_entre_pontos(mapa[posx][posy], mapa[posx_final][posy_final])*10);			
						mapa[posx][posy].setF(mapa[posx][posy].getG()+mapa[posx][posy].getH());
						
						// adiciona o vizinho na lista aberta
						aberta.add(mapa[posx][posy]);
					
					}else
					{
						if(aberta.contains(mapa[posx][posy]))
						{
							
							  
							/* 	///	 parte meio inutil por enquanto
							int tempg,tempf;
							mapa[posx][posy].setPai(mapa[posx_atual][posy_atual]);		// redefine o pai
							
							if(mapa[posx][posy].calcula_distancia_entre_pontos(mapa[posx][posy],mapa[posx_atual][posy_atual]) != 1)
							{
								tempg = mapa[posx_atual][posy_atual].getG() + 14;		// movimento diagonal
							}else
							{
								tempg = mapa[posx_atual][posy_atual].getG() + 10;		// movimento vertical ou horizontal
							}
							
							// otimizando o caminho
							if(tempg < mapa[posx][posy].getG())
							{
								//System.out.println("redefiniu caminho");
								mapa[posx][posy].setPai(mapa[posx_atual][posy_atual]);
								mapa[posx][posy].setG(tempg);	// redefinindo o g
								mapa[posx][posy].setF(mapa[posx][posy].getG() + mapa[posx][posy].getH());	//redefinindo o f
								
							}
							*/
							
						}
					}
				}
			}
			
			
			
		}
		
	}
	
	/* funcao nao usada
	  
	 
	
	public static boolean eh_vizinho(int x1,int x2,int y1,int y2)
	{
	    if((x1 == x2 && Math.abs(y1-y2) == 1) || (y1 == y2 && Math.abs(x1-x2) == 1))
	    {
	        return true;   
	    }else
	    {
	        if((Math.abs(x1 -x2) == 1 )&&(Math.abs(y1-y2)==1))
	        {
	            return true;
	        }else
	        {
	            return false;    
	        }
	    }
	}
	
	*/
	
	public static boolean eh_permitido(int x1,int x2,int y1,int y2)
	{// vizinho = {x1,y1} atual = {x2,y2} bloquia passos diagonais passando pela quina de um ponto bloqueado
		
			// errado 		X 1	 ->    X 1
			// errado		0 0        0 X
		
		
			// certo		X 1 ->	  X 1  -> 	X 1
			// certo		0 0		  X 0       X X 
		  boolean cond= true;
		  if(x1==(x2+1) && y1==(y2+1))
		  {
		    if(mapa[x2][y2+1].isBloquado() || mapa[x2+1][y2].isBloquado())
		    {
		      cond =  false;
		    }
		  }

		  if(x1==(x2-1) && y1==(y2+1) )
		  {
		    if(mapa[x2-1][y2].isBloquado() || mapa[x2][y2+1].isBloquado())
		    {
		      cond =  false;
		    }
		  }

		  if(x1==(x2+1) && y1==(y2-1))
		  {
		    if(mapa[x2][y2-1].isBloquado() || mapa[x2+1][y2].isBloquado())
		    {
		      cond =  false;
		    }
		  }

		  if(x1==(x2-1) && y1==(y2-1))
		  {
		    if(mapa[x2-1][y2].isBloquado() || mapa[x2][y2-1].isBloquado())
		    {
		      cond =  false;
		    }
		  }
				

		  return cond;
	}
	
}





