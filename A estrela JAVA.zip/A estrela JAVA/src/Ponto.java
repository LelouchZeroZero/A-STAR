
public class Ponto implements Comparable<Ponto>{
	private int x,y;
	private Ponto pai;
	private boolean bloquado = false,origem=false,destino=false;
	private int  f,g,h;
	private boolean caminho;
	
	
	public boolean isCaminho() {
		return caminho;
	}


	public void setCaminho(boolean caminho) {
		this.caminho = caminho;
	}


	public Ponto()
	{
		setX(0);
		setY(0);
		setPai(null);
		setBloquado(false);
		setOrigem(false);
		setDestino(false);
		setCaminho(false);
	}
	
	
	public int getF() {
		return f;
	}


	public void setF(int f) {
		if(getPai() != null)	// se tiver pai, o f ser� somado com o do pai
		{
			this.f = f + pai.getF();		
		}else
		{
			this.f = f;
		}
		
	}


	public int getG() {
		return g;
	}


	public void setG(int g) {
		if(getPai() != null)		// se tiver pai, o g ser� somado com o do pai
		{
			this.g = g + getPai().getG();
		}else
		{
			this.g = g;
		}
		
	}


	public int getH() {
		return h;
	}


	public void setH(int h) {
		this.h = h;
	}


	public boolean isOrigem() {
		return origem;
	}
	public void setOrigem(boolean origem) {
		this.origem = origem;
	}
	public boolean isDestino() {
		return destino;
	}
	public void setDestino(boolean destino) {
		this.destino = destino;
	}
	public boolean isBloquado() {
		return bloquado;
	}
	public void setBloquado(boolean bloquado) {
		this.bloquado = bloquado;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public Ponto getPai() {
		return pai;
	}
	public void setPai(Ponto pai) {
		this.pai = pai;
	}
	public int calcula_distancia_entre_pontos(Ponto a, Ponto b)
	{
		int custo;
		custo = (Math.abs((a.getX() - b.getX())) + Math.abs(a.getY()-b.getY()));
		return custo;
	}
	@Override
	public int compareTo(Ponto p) {
		return (int)(this.f - p.getF());
	}
		
	
}
